package org.kosta.springmvc9.model.vo;

public class DeptVO {
}
