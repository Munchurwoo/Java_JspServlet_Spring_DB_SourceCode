package org.kosta.springmvc9.model.dao;

public interface DeptDAO {
	public int getDeptCount();
}