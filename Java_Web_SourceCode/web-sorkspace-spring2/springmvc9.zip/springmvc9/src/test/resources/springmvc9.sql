select * from dept;
select count(*) from dept;