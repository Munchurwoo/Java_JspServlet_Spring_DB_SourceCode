package com.javalec.ex;

public class Pencil6B implements Pencil {

	@Override
	public void use() {
		System.out.println("6B굵기로 쓰입니다.");
	}

}
