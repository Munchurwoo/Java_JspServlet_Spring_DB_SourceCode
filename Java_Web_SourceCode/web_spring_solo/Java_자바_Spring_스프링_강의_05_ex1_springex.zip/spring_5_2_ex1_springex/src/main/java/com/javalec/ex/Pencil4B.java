package com.javalec.ex;

public class Pencil4B implements Pencil {

	@Override
	public void use() {
		System.out.println("4B 굵기로 쓰입니다.");
	}

}
