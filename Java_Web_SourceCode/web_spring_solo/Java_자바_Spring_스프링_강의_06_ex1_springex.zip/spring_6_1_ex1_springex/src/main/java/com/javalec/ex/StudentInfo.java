package com.javalec.ex;

public class StudentInfo {

	private Student student;
	
	public StudentInfo() {
		// TODO Auto-generated constructor stub
	}
	
	public void setStudent(Student student) {
		this.student = student;
	}
	
	public Student getStudent() {
		return student;
	}
	
}
