package com.javalec.spring_pjt_board.util;

import org.springframework.jdbc.core.JdbcTemplate;

public class Constant {
	
	public static JdbcTemplate template;
	
}
