package com.javalec.spring_pjt_board.command;

import org.springframework.ui.Model;

public interface BCommand {

	public void execute(Model model);
	
}
