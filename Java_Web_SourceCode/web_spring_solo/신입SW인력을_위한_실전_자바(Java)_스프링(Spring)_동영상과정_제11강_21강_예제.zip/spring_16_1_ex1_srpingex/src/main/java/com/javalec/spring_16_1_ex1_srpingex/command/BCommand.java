package com.javalec.spring_16_1_ex1_srpingex.command;

import org.springframework.ui.Model;

public interface BCommand {
	
	void execute(Model model);
	
}